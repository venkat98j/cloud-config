
package com.cs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "editType",
    "file"
})
public class Path {

    @JsonProperty("editType")
    private String editType;
    @JsonProperty("file")
    private String file;

    @JsonProperty("editType")
    public String getEditType() {
        return editType;
    }

    @JsonProperty("editType")
    public void setEditType(String editType) {
        this.editType = editType;
    }

    @JsonProperty("file")
    public String getFile() {
        return file;
    }

    @JsonProperty("file")
    public void setFile(String file) {
        this.file = file;
    }

}
