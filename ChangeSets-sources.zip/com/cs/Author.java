
package com.cs;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "absoluteUrl",
    "description",
    "fullName",
    "id",
    "property"
})
public class Author {

    @JsonProperty("absoluteUrl")
    private String absoluteUrl;
    @JsonProperty("description")
    private String description;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("id")
    private String id;
    @JsonProperty("property")
    private List<Property> property = null;

    @JsonProperty("absoluteUrl")
    public String getAbsoluteUrl() {
        return absoluteUrl;
    }

    @JsonProperty("absoluteUrl")
    public void setAbsoluteUrl(String absoluteUrl) {
        this.absoluteUrl = absoluteUrl;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("fullName")
    public String getFullName() {
        return fullName;
    }

    @JsonProperty("fullName")
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("property")
    public List<Property> getProperty() {
        return property;
    }

    @JsonProperty("property")
    public void setProperty(List<Property> property) {
        this.property = property;
    }

}
