
package com.cs;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "changeSet"
})
public class ChangeSets {

    @JsonProperty("changeSet")
    private ChangeSet changeSet;

    @JsonProperty("changeSet")
    public ChangeSet getChangeSet() {
        return changeSet;
    }

    @JsonProperty("changeSet")
    public void setChangeSet(ChangeSet changeSet) {
        this.changeSet = changeSet;
    }

}
