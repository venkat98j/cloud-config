
package com.cs;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "affectedPaths",
    "commitId",
    "timestamp",
    "author",
    "comment",
    "date",
    "id",
    "msg",
    "paths"
})
public class Item {

    @JsonProperty("affectedPaths")
    private List<String> affectedPaths = null;
    @JsonProperty("commitId")
    private String commitId;
    @JsonProperty("timestamp")
    private Integer timestamp;
    @JsonProperty("author")
    private Author author;
    @JsonProperty("comment")
    private String comment;
    @JsonProperty("date")
    private String date;
    @JsonProperty("id")
    private String id;
    @JsonProperty("msg")
    private String msg;
    @JsonProperty("paths")
    private List<Path> paths = null;

    @JsonProperty("affectedPaths")
    public List<String> getAffectedPaths() {
        return affectedPaths;
    }

    @JsonProperty("affectedPaths")
    public void setAffectedPaths(List<String> affectedPaths) {
        this.affectedPaths = affectedPaths;
    }

    @JsonProperty("commitId")
    public String getCommitId() {
        return commitId;
    }

    @JsonProperty("commitId")
    public void setCommitId(String commitId) {
        this.commitId = commitId;
    }

    @JsonProperty("timestamp")
    public Integer getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(Integer timestamp) {
        this.timestamp = timestamp;
    }

    @JsonProperty("author")
    public Author getAuthor() {
        return author;
    }

    @JsonProperty("author")
    public void setAuthor(Author author) {
        this.author = author;
    }

    @JsonProperty("comment")
    public String getComment() {
        return comment;
    }

    @JsonProperty("comment")
    public void setComment(String comment) {
        this.comment = comment;
    }

    @JsonProperty("date")
    public String getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(String date) {
        this.date = date;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("msg")
    public String getMsg() {
        return msg;
    }

    @JsonProperty("msg")
    public void setMsg(String msg) {
        this.msg = msg;
    }

    @JsonProperty("paths")
    public List<Path> getPaths() {
        return paths;
    }

    @JsonProperty("paths")
    public void setPaths(List<Path> paths) {
        this.paths = paths;
    }

}
